import React from 'react'
import Iframe from 'react-iframe'

const AddEmployee = () => {
  return (
    <div>
       <iframe frameborder="1" width="420" height="345" src="//http://127.0.0.1:8000/"></iframe> 

    </div>
  )
}

export default AddEmployee