import React, {useState} from 'react'
import { Signup } from './Signup'

export const Admin_Login = () => {
    const [username, setusername] = useState();
    const [password, setpassword] = useState();
    const [redirect, setredirect] = useState('');

    function eventHandler(event) {
        const value = event.target.value;
        setusername(value);
    }

    function eventHandler1(event) {
        const value = event.target.value;
        setpassword(value);
    }

    function onSubmit() {
        if (username !== 'admin' && password !== 'admin') {
            alert(`invalid user inputs: `)
            setredirect('/admin_signup');
        }
        else {
            alert(`Hello ${username} ypu are successfully signed in:`)
            setredirect('/admin_dashboard')
        }
    }
    return (
    <>

       <Signup
       title = "Admin"
       placeholder1 = "Your Username"
       button = "Sign in"
       redirect = {redirect}
       e1 = {eventHandler}
       e2 = {eventHandler1}
       onSubmit = {onSubmit}
       />
    </>
  )
}
