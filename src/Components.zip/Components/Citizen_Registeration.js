import React, { useEffect, useState } from 'react';
import axios from 'axios';

export const Citizen_Registeration = () => {
    const [first_name, setfirst_name] = useState();
    const [last_name, setlast_name] = useState();
    const [email, setemail] = useState();
    const [phone, setphone] = useState();
    const [password, setpassword] = useState();
    
    //http://localhost:3001/register'
    
    function onSubmit() {
        axios.post('http://127.0.0.1:8000/backend/register/', {
            first_name: first_name,
            last_name: last_name,
            email: email,
            phone: phone,
            password: password,
        })
        
    }

    return (
        <>
            <div class="section">
                <div class="container">
                    <div class="row full-height justify-content-center">
                        <div class="col-12 text-center align-self-center py-5">
                            <div class="section pb-5 pt-5 pt-sm-2 text-center">
                                {/* <h6 class="mb-0 pb-3"><span>Log In </span><span>Sign Up</span></h6> */}
                                {/* <input class="checkbox" type="checkbox" id="reg-log" name="reg-log" />
                                <label for="reg-log"></label> */}
                                <div class="card-3d-wrap1 mx-auto">
                                    <div class="card-3d-wrapper1">
                                        <div class="card-front1">
                                            <div class="center-wrap1">
                                                <div class="section text-center">
                                                    <h4 class="mb-4 pb-3"><span>Citizen</span> Registeration</h4>
                                                    <div class="form-group">
                                                        <input onChange={(e) => {
                                                            setfirst_name(e.target.value);
                                                        }} type="text" name="firstname" class="form-style" placeholder="Enter First Name" id="logemail" autocomplete="off" />
                                                        <i class="input-icon uil uil-at"></i>
                                                    </div>
                                                    <div class="form-group">
                                                        <input onChange={(e) => {
                                                            setlast_name(e.target.value);
                                                        }} type="text" name="secondname" class="form-style" placeholder="Enter Second Name" id="logemail" autocomplete="off" />
                                                        <i class="input-icon uil uil-at"></i>
                                                    </div>
                                                    <div class="form-group mt-2">
                                                        <input onChange={(e) => {
                                                            setemail(e.target.value);
                                                        }} type="email" name="email" class="form-style" placeholder="Your E-mail" id="logpass" autocomplete="off" />
                                                        <i class="input-icon uil uil-lock-alt"></i>
                                                    </div>
                                                    <div class="form-group mt-2">
                                                        <input onChange={(e) => {
                                                            setphone(e.target.value);
                                                        }} type="text" name="address" class="form-style" placeholder="Your Address" id="logpass" autocomplete="off" />
                                                        <i class="input-icon uil uil-lock-alt"></i>
                                                    </div>
                                                    <div class="form-group mt-2">
                                                        <input onChange={(e) => {
                                                            setpassword(e.target.value);
                                                        }} type="password" name="password" class="form-style" placeholder="Your Password" id="logpass" autocomplete="off" />
                                                        <i class="input-icon uil uil-lock-alt"></i>
                                                    </div>
                                                    <a onClick={onSubmit} className="btn mt-4">Register</a>
                                                    <p class="mb-0 mt-4 text-center"><a href="#0" class="link">Forgot your password?</a></p>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}



