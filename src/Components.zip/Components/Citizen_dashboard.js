import React from 'react'
import { Link } from 'react-router-dom';
//import './assets/css/fonts.css';
import CitizenProfile from './CitizenProfile';
import ComplainPage from './ComplainPage';
import { useState } from 'react';
import Nocomplain from './Nocomplain';



const datetime = new Date().toDateString();

export const Citizen_dashboard = () => {
  
  const [myBool, setmyBool] = useState(true);

  const [conditionA, setconditionA] = useState(false);
  const [conditionB, setconditionB] = useState(false);

  function toggleBool() {
    setmyBool(!myBool)
  }
    

  return (

    


    <>

      <nav className="navbar fixed-top navbar-expand-md navbar-dark bg-dark mb-3">
        <div className="flex-row d-flex">
        <div className="flex-row d-flex">
  
        <div className="logo">i<spam>G</spam>arb0</div>
      </div>
        </div>
        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsingNavbar">
          <span className="navbar-toggler-icon" />
        </button>
        <div className="navbar-collapse collapse" id="collapsingNavbar">
          
          <ul className="navbar-nav ml-auto">
            <li className="nav-item">
              <a className="nav-link" href="#myAlert" data-toggle="collapse">Alert</a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href data-target="#myModal" data-toggle="modal">About</a>
            </li>
            <li className="nav-item">
              <a className="nav-link waves-effect waves-light text-white">
                <i className="fab fa-google-plus-g" />
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link waves-effect waves-light text-white">
                <i className="fas fa-envelope-open-text" />
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link waves-effect waves-light text-white">
                <i className="fas fa-align-justify" />
              </a>
            </li>
          </ul>
        </div>
      </nav>

      {/*nav close */}
      <div class="container-fluid" id="main">
      <div class="row row-offcanvas row-offcanvas-left">
            

            <div class="col-md-3 col-lg-2 sidebar-offcanvas pl-0" id="sidebar" role="navigation" style={{backgroundColor:'#43484C'}}>
                  <ul class="nav flex-column sticky-top pl-0 pt-5 p-3 mt-3 "  >
                      <li class="nav-item mb-2 mt-3"><a class="nav-link text-secondary" href="#"><h4 style={{color:'#fff'}} >Welcome!</h4> <h5 style={{color:'#fff'}}><br></br> Mr. Hashim</h5></a></li>
                      <li class="nav-item mb-2 "><a class="nav-link text-secondary" href="/complain"><i  style={{color:'#fff'}} class="fas fa-user font-weight-bold"></i> <span className="ml-3" style={{color:'#fff'}}>My Profile</span></a></li>
                      <li class="nav-item mb-2">
                          <a class="nav-link text-secondary" href="#submenu1" data-toggle="collapse" data-target="#submenu1"><i style={{color:'#fff'}}  class="far fa-file-word font-weight-bold"></i> <span className="ml-3" style={{color:'#fff'}} > Complain▾</span></a>
                          <ul class="list-unstyled flex-column pl-3 collapse" id="submenu1" aria-expanded="false">
                            <li class="nav-item mb-2 "><a onClick={toggleBool} class="nav-link text-secondary" ><i  style={{color:'#fff'}}  class=" fas fa-book-medical"></i><span  style={{color:'#fff'}}  className="ml-3">Add</span> </a></li>
                            <li class="nav-item mb-2 "  ><Link to="/nocomplain" class="nav-link text-secondary" > <i  style={{color:'#fff'}}  class="fas fa-book-reader "></i> <span  style={{color:'#fff'}}  className="ml-3">View</span> </Link></li>
                          </ul>
                      </li>
                      <li class="nav-item mb-2"><a class="nav-link text-secondary" onClick={toggleBool}><i style={{color:'#fff'}} class="far fa-chart-bar font-weight-bold"></i> <span className="ml-3" style={{color:'#fff'}}>Notifications</span></a></li>
                    
                  </ul>
            </div>

            <div class="col main pt-5 mt-3" >
              
            {/*<CitizenProfile/>*/}
            <span>
                {conditionA ? <CitizenProfile  /> 
                  : conditionB ?  <ComplainPage />  
                  : <Nocomplain /> }
            </span>;

           { /*myBool ? <CitizenProfile  /> : <ComplainPage /> */}
            </div>
            
            </div>
      </div>     
       


      

    </>
  )
}
