import axios from 'axios';
import React, { useState } from 'react'
import { Signup } from './Signup'

export const Citzen_sinin = () => {

    const [email, setemail] = useState();
    const [password, setpassword] = useState();
    const [redirect, setredirect] = useState('');
    const [alldata, setalldata] = useState([])


    function eventHandler(event) {
        const value = event.target.value;
        setemail(value);
    }

    function eventHandler1(event) {
        const value = event.target.value;
        setpassword(value);
    }

    axios.post('http://127.0.0.1:8000/backend/signin/',).then((response) => {
        setalldata(response.data)
        console.log(alldata)
    }).catch(() => {
        console.log('data not retreived')
    })


    function onSubmit() {
            if (alldata.status === "0") {
                alert(`invalid user inputs: `)
                setredirect('/citizen_signup');
            }
            else {
                alert(`Hello you are successfully signed in:`)
                setredirect('/citizen_dashboard')
            }            
    }

    return (
        <>
            <Signup
                title="Citizen"
                placeholder1="Your Username"
                button="Sign in"
                redirect={redirect}
                e1={eventHandler}
                e2={eventHandler1}
                onSubmit={onSubmit}
            />

        </>
    )
}
