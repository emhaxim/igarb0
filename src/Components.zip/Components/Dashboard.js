//import {useEffect,useState} from 'react';
//import axios from 'axios';
import {Chart, ArcElement} from 'chart.js'
import 'bootstrap/dist/css/bootstrap.min.css';
import Adhashbody from './Adhashbody';
import AdhashSide from './AdhashSide';


Chart.register(ArcElement);

const Dashboard = () => {
   
    
  //const[record,setRecord] = useState([])
  

  /* const getData = () =>
   {
       axios.get('https://jsonplaceholder.typicode.com/users')
       .then((response) => {
        setRecord(response.data)})
       
   }
   
   useEffect(() => {
      getData();
   },)
    
   console.log(record)*/
    return (
     <>
    


      <nav className="navbar fixed-top navbar-expand-md navbar-dark bg-dark mb-3" >
  <div className="flex-row d-flex">
  
    <div className="logo">i<spam>G</spam>arb0</div>
  </div>
  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsingNavbar">
    <span className="navbar-toggler-icon" />
  </button>
  <div className="navbar-collapse collapse" id="collapsingNavbar">
    <ul className="navbar-nav">
      <li className="nav-item active">
        <a className="nav-link" href="#">Home <span className="sr-only">Home</span></a>
      </li>
      <li className="nav-item">
        <a className="nav-link" href="//www.codeply.com">Link</a>
      </li>
    </ul>
    <ul className="navbar-nav ml-auto">
      <li className="nav-item">
        <a className="nav-link" href="#myAlert" data-toggle="collapse">Alert</a>
      </li>
      <li className="nav-item">
        <a className="nav-link" href data-target="#myModal" data-toggle="modal">About</a>
      </li>
      <li className="nav-item">
        <a className="nav-link waves-effect waves-light text-white">
          <i className="fab fa-google-plus-g" />
        </a>
      </li>
      <li className="nav-item">
        <a className="nav-link waves-effect waves-light text-white">
          <i className="fas fa-envelope-open-text" />
        </a>
      </li>
      <li className="nav-item">
        <a className="nav-link waves-effect waves-light text-white">
          <i className="fas fa-align-justify" />
        </a>
      </li>
    </ul>
  </div>
</nav>
<br></br>

{/*nav close */}

{/*side bar*/}

<div class="container-fluid" id="main" style={{backgroundImage:'None'}}>
<div class="row row-offcanvas row-offcanvas-left">
      
      <AdhashSide/>
      <Adhashbody/>
  </div>
</div>
     
      
{/*dashboard */}



</>
    )
}
 
export default Dashboard;