import React from 'react'
import Breadcrumb from 'react-bootstrap/Breadcrumb'
import 'bootstrap/dist/css/bootstrap.min.css';
import {Container ,Card,Row, Col, Button} from 'react-bootstrap';


function CitizenProfile(props) {
    return (
       
        <section style={{backgroundColor: '#FAF9F6'}} >
          
          <div className="container py-5">
            <div className="row">
              <div className="col-lg-4">
                <div className="card mb-4">
          
                  <div className="card-body text-center">
                    <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava3.webp" alt="avatar" className="rounded-circle img-fluid" style={{width: '150px'}} />
                    <h5 className="my-3">Hashim Khan</h5>
                    <p className="text-muted mb-1">Member since 2020</p>
                    <p className="text-muted mb-4">Rawalpindi, Pakistan</p>
                    <div className="d-flex justify-content-center mb-2">
                      <button type="button" className="btn btn-primary" onClick={props.toggleBool}>Follow</button>
                      <button type="button" className="btn btn-outline-primary ms-1">Message</button>
                    </div>
                  </div>
                </div>

                <div className="card mb-4 mb-lg-0">
                  <div className="card-body p-0">
                    <ul className="list-group list-group-flush rounded-3">
                      <li className="list-group-item d-flex justify-content-between align-items-center p-3">
                        <i className="fas fa-globe fa-lg text-warning" />
                        <p className="mb-0">https://mdbootstrap.com</p>
                      </li>
                     
                      <li className="list-group-item d-flex justify-content-between align-items-center p-3">
                        <i className="fab fa-instagram fa-lg" style={{color: '#ac2bac'}} />
                        <p className="mb-0">mdbootstrap</p>
                      </li>
                      <li className="list-group-item d-flex justify-content-between align-items-center p-3">
                        <i className="fab fa-facebook-f fa-lg" style={{color: '#3b5998'}} />
                        <p className="mb-0">mdbootstrap</p>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="col-lg-8">
                <div className="card mb-4">
                  <div className="card-body">
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Full Name</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">Mr. emhaxim</p>
                      </div>
                    </div>
                    <hr />
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Email</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">emhaxim@example.com</p>
                      </div>
                    </div>
                    <hr />
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Phone</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">(+92) 234-5678</p>
                      </div>
                    </div>
                    <hr />
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Mobile</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">(+92) 765-4321</p>
                      </div>
                    </div>
                    <hr />
                    <div className="row">
                      <div className="col-sm-3">
                        <p className="mb-0">Address</p>
                      </div>
                      <div className="col-sm-9">
                        <p className="text-muted mb-0">Rawalpindi, Pakistan</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-6">
                    <div className="card mb-4 mb-md-0">
                      <div className="card-body">
                        <p className="mb-4"><span className="text-primary font-italic me-1">Profile</span> Status
                        </p>
                        <p className="mb-1" style={{fontSize: '.77rem'}}>Profile Completion</p>
                        <div className="progress rounded" style={{height: '5px'}}>
                          <div className="progress-bar" role="progressbar" style={{width: '80%'}} aria-valuenow={80} aria-valuemin={0} aria-valuemax={100} />
                        </div>
                        <p className="mt-4 mb-1" style={{fontSize: '.77rem'}}>feedback</p>
                        <div className="progress rounded" style={{height: '5px'}}>
                          <div className="progress-bar" role="progressbar" style={{width: '60%'}} aria-valuenow={72} aria-valuemin={0} aria-valuemax={100} />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="card mb-4 mb-md-0">
                      <div className="card-body">
                        <p className="mb-4"><span className="text-primary font-italic me-1">Complaint</span> Status
                        </p>
                        <p className="mb-1" style={{fontSize: '.77rem'}}>Complaints Submission</p>
                        <div className="progress rounded" style={{height: '5px'}}>
                          <div className="progress-bar" role="progressbar" style={{width: '80%'}} aria-valuenow={80} aria-valuemin={0} aria-valuemax={100} />
                        </div>
                        <p className="mt-4 mb-1" style={{fontSize: '.77rem'}}>Complaints Resolved</p>
                        <div className="progress rounded" style={{height: '5px'}}>
                          <div className="progress-bar" role="progressbar" style={{width: '72%'}} aria-valuenow={72} aria-valuemin={0} aria-valuemax={100} />
                        </div>
                       
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"></link>
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
          <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet"></link>
        </section>
      );
 
}

export default CitizenProfile


