import React from 'react'
import '../index.css';
import video from '../images/video.mp4';
import { Signup } from './Signup';
import { About } from './About';
import { Navbar } from './Navbar';
import Typical from "react-typical";

export const Main = () => {


    return (
        <> <Navbar/>
            <div className="main1">
                <div className="main1_container">
                    <h1 className="heading">let's Make <span>Pakistan</span></h1>

                    <Typical className = "typical heading_support" 
                    loop = {Infinity}
                    wrapper = "p"
                    steps= {[
                        
                        "Clean And Green",
                         1000,
                         "Beautiful",
                         1000,
                    ]}/>

                    {/*<p className="heading_support">Clean and Green</p>*/}

                    {/* <!-- Hover #1 --> */}
                    <div class="box-1">
                        <div   class="btnn btn-one">
                            <span>GET STARTED</span>
                        </div>
                    </div>

                    
                </div>
            </div>
            <About/>
        </>
    )
}
