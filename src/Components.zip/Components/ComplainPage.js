import React from 'react'
import { useState } from 'react';
import axios from 'axios';



import Button from 'react-bootstrap/Button';
import Form from "react-bootstrap/Form";
import InputGroup from 'react-bootstrap/InputGroup';   
const ComplainPage = () => {

  const [Compalain_date, setCompalain_date] = useState();
  const [Complain_location, setComplain_location] = useState('aa');
  const [Major_issue, setMajor_issue] = useState();
  const [Complain_Description, setComplain_Description] = useState();

  function onSubmit() {
    axios.post('http://127.0.0.1:8000/backend/addcomplain/', {
        Compalain_date: Compalain_date,
        Major_issue: Major_issue,
        Complain_location: Complain_location,
        Complain_Description: Complain_Description,
        
    })
    
}

  return (
    <section style={{backgroundColor: '#FAF9F6'}} >


        
    <div className="container py-5" >
    <Form>  
    <div className="logo"  ><spam style={{color: '#215C84'}}>Please file your Complain!</spam></div>
      <div className="row">
        <div className="col-lg-12">
   

        </div>
       
        <div className="col-lg-12">
          <div className="card mb-4">
            <div className="card-body">

              {/*Date*/}
              <div className="row">
                <div className="col-sm-3">
                  
                  <p className="mb-0" style={{fontWeight:'bold', fontSize:'20px'}}>Date</p>
                  
                </div>
                <div className="col-sm-3">
                <Form.Control onChange={(e) => {setCompalain_date(e.target.value);}} type="date"></Form.Control>
                </div>               
              </div>
              <br/>
              {/*Date end*/}

              {/*Major Complain issue*/}

              <div className="row">
                <div className="col-sm-3">
                  <p className="mb-0" style={{fontWeight:'bold' , fontSize:'20px'}}>Select major issue</p>
                </div>
                <div className="col-sm-6">
                <Form.Check 
                    type="radio"
                    label="Garbage Overflow"
                    name="group2"
                    id="radio1"
                    onChange={(e) => {setMajor_issue(e.target.value);}}
                    
                /> 
                <Form.Check
                    type="radio"
                    label="Untideness"
                    name="group2"
                    id="radio2" 
                    onChange={(e) => {setMajor_issue(e.target.value);}}
                /> 
                <Form.Check
                    type="radio"
                    label="Sewerage"
                    name="group2"
                    id="radio3"
                    onChange={(e) => {setMajor_issue(e.target.value);}}
                /> 
                <Form.Check
                    type="radio"
                    label="Other"
                    name="group2"
                    id="radio4"
                    onChange={(e) => {setMajor_issue(e.target.value);}}
                /> 
                </div>
              </div>
              <hr />
              {/*Major Complain issue end*/}

              {/*Address*/}
              <div className="row">
                
              <InputGroup size="lg">
                    <InputGroup.Text id="inputGroup-sizing-lg" 
                                     style={{fontWeight:'bold', fontSize:'20px'}}
                                     onChange={(e) => {setComplain_location(e.target.value);}}>

                                Enter Location :   

                     </InputGroup.Text>
                <Form.Control
                
                  aria-label="Small"
                  aria-describedby="basic-addon1"
                />
              </InputGroup>
              </div>
              {/*Address end*/}

               {/*Write Complain */}
              <div className="row">
                <div className="col-sm-9">

                  <br/><div   ><b>Write your Complaint in the box below:</b></div><br/>
                </div>
                <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                 
                  <Form.Control as="textarea" rows={3}   onChange={(e) => {setComplain_Description(e.target.value);}} />
                </Form.Group>
              </div>
              {/*Write Complain end */}

              <Button className="pull-right" variant="primary" type="submit" onClick={onSubmit} >
              Submit
            </Button>
            </div>
          </div>
        
        </div>
      </div>
      
    </Form>

    </div>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"></link>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet"></link>
  </section>
  )
}

export default ComplainPage