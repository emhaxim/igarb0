import React from 'react'
import '../index.css';
import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';

export const Signup = (props) => {
    return (
        <>
            <div class="section">
                <div class="container">
                    <div class="row full-height justify-content-center">
                        <div class="col-12 text-center align-self-center py-5">
                            <div class="section pb-5 pt-5 pt-sm-2 text-center">
                                {/* <h6 class="mb-0 pb-3"><span>Log In </span><span>Sign Up</span></h6> */}
                                {/* <input class="checkbox" type="checkbox" id="reg-log" name="reg-log" />
                                <label for="reg-log"></label> */}
                                <div class="card-3d-wrap1 mx-auto">
                                    <div class="card-3d-wrapper1">
                                        <div class="card-front1">
                                            <div class="center-wrap1">
                                                <div class="section text-center">
                                                    <h4 class="mb-4 pb-3"><span>{props.title}</span> Log In</h4>
                                                    <div class="form-group">
                                                        <input onChange={props.e1} type="text" name="logemail" class="form-style" placeholder={props.placeholder1} id="logemail" autocomplete="off" />
                                                            <i class="input-icon uil uil-at"></i>
                                                    </div>
                                                    <div class="form-group mt-2">
                                                        <input  type="email" name="logpass" class="form-style" placeholder="Your E-mail" id="logpass" autocomplete="off"/>
                                                            <i class="input-icon uil uil-lock-alt"></i>
                                                    </div>
                                                    <div class="form-group mt-2">
                                                        <input onChange={props.e2} type="password" name="logpass" class="form-style" placeholder="Your Password" id="logpass" autocomplete="off"/>
                                                            <i class="input-icon uil uil-lock-alt"></i>
                                                    </div>
                                                    <a onClick={props.onSubmit} href={props.redirect} class="btn mt-4">{props.button}</a>

                                                    <p class="mb-0 mt-4 text-center" style={{color:"gray"}}>Please click <Link to="/citizen_registeration" class="link">here</Link> for registration!</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
