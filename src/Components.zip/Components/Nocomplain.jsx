import nocomplain from'..//images//nocomplain.gif'

import React from 'react'

const Nocomplain = () => {
  return (
    < div style={{backgroundColor:"white"}}>
        
        
        <img src={nocomplain} alt="loading..." />
        
    </div>
  )
}

export default Nocomplain